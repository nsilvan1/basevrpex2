local cfg = {}

cfg.db = {
	driver = "ghmattimysql",
	host = "127.0.0.1",
	database = "cruz",
	user = "root",
	password = ""
}

return cfg