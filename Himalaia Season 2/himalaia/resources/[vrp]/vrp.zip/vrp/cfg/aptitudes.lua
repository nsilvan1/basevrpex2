local cfg = {}

cfg.gaptitudes = {
	["physical"] = {
		_title = "Mochila",
		["strength"] = { "Forca",20,1900 }
	}
}

return cfg