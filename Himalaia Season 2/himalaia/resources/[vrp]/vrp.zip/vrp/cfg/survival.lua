local cfg = {}

cfg = {
  thirst_per_minute = 0.1,
  hunger_per_minute = 0.1,
  overflow_damage_factor = 10,
  pvp = true,
  police = false
}

return cfg